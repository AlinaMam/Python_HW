
def new_func (a, b):
    try:
        result = a // b
        return result
    except ZeroDivisionError:
        return "На ноль делить нельзя"
print(new_func(int(input("Введите первое число: "))), int(input("Введите второе число: "))))