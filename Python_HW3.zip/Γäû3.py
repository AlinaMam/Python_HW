def new_func(a, b, c):
    flow = [a, b, c]
    result = []
    max_1 = max(flow)
    result.append(max_1)
    flow.remove(max_1)
    max_2 = max(flow)
    result.append(max_2)
    print(sum(result))
new_func(5, 8, 9)

