name = input('Введите имя: ')
surname = input('Введите фамилию: ')
year = int(input('Введите год рождения: '))
city = input('Введите город проживания: ')
email = input('Введите email: ')
phone = int(input('Введите телефон: '))


def new_func(name, surname, year, city, email, phone):
    print(name, surname, year, city, email, phone)
new_func(name, surname, year, city, email, phone)


