
from functools import reduce
new_list1 = [el for el in range(100, 1001) if el % 2 == 0]
def new_list2(el_a, el):
    return el_a * el
print(reduce(new_list2, new_list1))

