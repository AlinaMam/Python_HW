
# код не работает, помогите, пожалуйста, исправить ошибку
from sys import argv
name, hours, rate, bonus = argv
salary = int(hours) * int(rate) + int(bonus)
print(f"Заработная плата, {salary}")



