# Поработайте с переменными, создайте несколько, выведите на экран, запросите у пользователя
# несколько чисел и строк и сохраните в переменные, выведите на экран

value = 110 - 6
print(value)

value = 5 * 5
print(value)

value = 100 / 2
print(value)

date_of_birth = input("Введите дату рождения >>>")
print(date_of_birth)

important_date = input("Когда Россия откроет границы >>>")
print(important_date)

