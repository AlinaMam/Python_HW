# Пользователь вводит время в секундах. Переведите время в часы, минутыи секунды и выведите в формате чч:мм:сс.
# Используйте форматирование строк.

time_seconds = int(input("Введите время в секундах: "))
print(time_seconds)

hours = time_seconds // 3600
print(hours)

minutes = time_seconds // 60
print(minutes)

print("{0}:{1}:{2}".format(hours, minutes, time_seconds))

