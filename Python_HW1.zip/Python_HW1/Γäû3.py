# Узнайте у пользователя число n. Найдите сумму чисел n + nn + nnn. Например, пользователь ввёл число 3.
# Считаем 3 + 33 + 333 = 369

n = int(input("Введите любое число: "))
print(n)
number1 = n + n
number2 = n + n + n
total = n + int(number1) + int(number2)
print("Сумма чисел n + nn + nnn:", total)



